package com.radartormenta.app

import android.content.Context
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Hit(val distKm: Double, val bearing: Double)

object StormChecker {
    private const val Z = 7
    private const val RAIN_URL = "https://api.rainviewer.com/public/weather-maps.json"
    private val DIRS = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
    private val ARROWS = arrayOf("↓", "↙", "←", "↖", "↑", "↗", "→", "↘")

    private fun sector(deg: Double): Int = ((((deg % 360.0) + 360.0) % 360.0 + 22.5) / 45.0).toInt() % 8
    fun compass(deg: Double): String = DIRS[sector(deg)]
    fun arrow(fromDeg: Double): String = ARROWS[sector(fromDeg)]

    fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "RadarTormenta/1.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun httpGetBytes(url: String): ByteArray? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "RadarTormenta/1.0")
            try {
                if (c.responseCode != 200) null else c.inputStream.use { it.readBytes() }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Busca el pixel con lluvia mas cercano al usuario en un mosaico de 3x3 teselas. */
    private fun nearestRain(host: String, path: String, lat: Double, lon: Double): Hit? {
        val n = 1 shl Z
        val world = 256.0 * n
        val latRad = Math.toRadians(lat)
        val px = (lon + 180.0) / 360.0 * world
        val py = (1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * world
        val tx = (px / 256.0).toInt()
        val ty = (py / 256.0).toInt()
        var best = Double.MAX_VALUE
        var bdx = 0.0
        var bdy = 0.0
        val buf = IntArray(256 * 256)
        for (oy in -1..1) {
            for (ox in -1..1) {
                val x = tx + ox
                val y = ty + oy
                if (x < 0 || x >= n || y < 0 || y >= n) continue
                val bytes = httpGetBytes("$host$path/256/$Z/$x/$y/2/1_1.png") ?: continue
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
                if (bmp.width != 256 || bmp.height != 256) {
                    bmp.recycle()
                    continue
                }
                bmp.getPixels(buf, 0, 256, 0, 0, 256, 256)
                bmp.recycle()
                var j = 0
                while (j < 256) {
                    var i = 0
                    while (i < 256) {
                        val a = buf[j * 256 + i] ushr 24
                        if (a >= 110) {
                            val dx = x * 256.0 + i - px
                            val dy = y * 256.0 + j - py
                            val d2 = dx * dx + dy * dy
                            if (d2 < best) {
                                best = d2
                                bdx = dx
                                bdy = dy
                            }
                        }
                        i += 2
                    }
                    j += 2
                }
            }
        }
        if (best == Double.MAX_VALUE) return null
        val mpp = 156543.03392 * Math.cos(latRad) / n
        val km = Math.sqrt(best) * mpp / 1000.0
        val bearing = (Math.toDegrees(Math.atan2(bdx, -bdy)) + 360.0) % 360.0
        return Hit(km, bearing)
    }

    fun check(ctx: Context, lat: Double, lon: Double): Status {
        val alertKm = Store.alertKm(ctx)

        // ---- Tiempo actual y pronostico (Open-Meteo)
        var weatherOk = false
        var temp = Double.NaN
        var wind = 0.0
        var windDir = 0.0
        var gust = 0.0
        var precip = 0.0
        var thunderSoon = false
        try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m" +
                "&hourly=weather_code,wind_gusts_10m&forecast_hours=3&timezone=auto&wind_speed_unit=kmh"
            val w = JSONObject(httpGet(url))
            val c = w.getJSONObject("current")
            temp = c.optDouble("temperature_2m", Double.NaN)
            wind = c.optDouble("wind_speed_10m", 0.0)
            windDir = c.optDouble("wind_direction_10m", 0.0)
            gust = c.optDouble("wind_gusts_10m", 0.0)
            precip = c.optDouble("precipitation", 0.0)
            if (c.optInt("weather_code", 0) in 95..99) thunderSoon = true
            val h = w.getJSONObject("hourly")
            val codes = h.getJSONArray("weather_code")
            for (i in 0 until codes.length()) {
                if (codes.optInt(i, 0) in 95..99) thunderSoon = true
            }
            val gs = h.getJSONArray("wind_gusts_10m")
            for (i in 0 until gs.length()) {
                gust = maxOf(gust, gs.optDouble(i, 0.0))
            }
            weatherOk = true
        } catch (e: Exception) {
        }

        // ---- Radar (RainViewer): ahora y ~30 min antes
        var radarOk = false
        var hitNow: Hit? = null
        var hitPrev: Hit? = null
        var dtMin = 0.0
        try {
            val j = JSONObject(httpGet(RAIN_URL))
            val host = j.getString("host")
            val past = j.getJSONObject("radar").getJSONArray("past")
            if (past.length() > 0) {
                val lastIdx = past.length() - 1
                val refIdx = maxOf(0, lastIdx - 3)
                val last = past.getJSONObject(lastIdx)
                val ref = past.getJSONObject(refIdx)
                dtMin = (last.getLong("time") - ref.getLong("time")) / 60.0
                hitNow = nearestRain(host, last.getString("path"), lat, lon)
                if (refIdx != lastIdx) {
                    hitPrev = nearestRain(host, ref.getString("path"), lat, lon)
                }
                radarOk = true
            }
        } catch (e: Exception) {
        }

        val now = hitNow
        val prev = hitPrev
        var approach = 0.0
        if (now != null && prev != null && dtMin >= 10.0) {
            approach = (prev.distKm - now.distKm) / (dtMin / 60.0)
        }
        val approaching = now != null && approach >= 8.0
        var eta = -1
        if (approaching && now != null && now.distKm > 0.5) {
            eta = (now.distKm / approach * 60.0).toInt()
        }

        // ---- Texto del radar
        var radarText = ""
        if (now != null) {
            val km = now.distKm.toInt()
            radarText = if (km < 3) {
                "Lluvia sobre tu ubicación"
            } else {
                "Lluvia a $km km al ${compass(now.bearing)}"
            }
            radarText += if (approaching) {
                " · se acerca a ${approach.toInt()} km/h" + (if (eta >= 0) " · llega en ~$eta min" else "")
            } else if (prev != null && approach <= -8.0) {
                " · se aleja"
            } else {
                " · sin acercarse"
            }
        } else if (radarOk) {
            radarText = "Sin lluvia en el radar cerca de ti"
        }

        // ---- Nivel y titulares
        var level = 0
        var headline = "Sin tormentas cerca"
        val parts = ArrayList<String>()

        val rainingNow = (now != null && now.distKm < 3.0) || (!radarOk && precip >= 0.1)

        if (!weatherOk && !radarOk) {
            headline = "Sin datos"
            parts.add("Revisa tu conexión a internet")
        } else if (thunderSoon) {
            level = 2
            headline = "⚡ Tormenta eléctrica prevista"
            parts.add("En las próximas 3 horas en tu zona")
            if (radarText.isNotEmpty()) parts.add(radarText)
        } else if (gust >= 70.0) {
            level = 2
            headline = "💨 Ráfagas fuertes previstas"
            parts.add("Hasta ${gust.toInt()} km/h")
            if (radarText.isNotEmpty()) parts.add(radarText)
        } else if (approaching && now != null && now.distKm <= alertKm && (eta < 0 || eta <= 120)) {
            level = 2
            headline = "⚠ Lluvia o tormenta acercándose"
            parts.add(radarText)
        } else if (rainingNow) {
            level = 1
            headline = "🌧 Lluvia en tu zona"
            if (radarText.isNotEmpty()) parts.add(radarText)
        } else if (approaching && now != null && now.distKm <= 100.0) {
            level = 1
            headline = "🌦 Lluvia a ${now.distKm.toInt()} km"
            parts.add(radarText)
        } else {
            if (radarText.isNotEmpty()) parts.add(radarText)
        }

        var conditions = ""
        if (weatherOk) {
            val t = if (temp.isNaN()) "" else "${temp.toInt()}° · "
            conditions = "${t}💨 ${wind.toInt()} km/h ${arrow(windDir)} del ${compass(windDir)}"
            if (gust > wind + 5.0) conditions += " · ráfagas ${gust.toInt()}"
        }

        return Status(level, headline, parts.joinToString("\n"), conditions, System.currentTimeMillis())
    }
}
