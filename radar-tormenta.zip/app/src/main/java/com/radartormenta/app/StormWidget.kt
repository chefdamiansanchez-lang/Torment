package com.radartormenta.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StormWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Scheduler.ensure(context)
        Scheduler.now(context)
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    override fun onEnabled(context: Context) {
        Scheduler.ensure(context)
    }

    companion object {
        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, StormWidget::class.java))
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx))
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_storm)
            val s = Store.loadStatus(ctx)
            if (s == null) {
                v.setTextViewText(R.id.w_headline, "Abre Radar Tormenta")
                v.setTextColor(R.id.w_headline, Color.WHITE)
                v.setTextViewText(R.id.w_detail, "Entra una vez para dar permisos y activar los avisos")
                v.setTextViewText(R.id.w_updated, "")
            } else {
                val color = when (s.level) {
                    2 -> Color.parseColor("#FF4D4D")
                    1 -> Color.parseColor("#FFB020")
                    else -> Color.parseColor("#3DDC84")
                }
                v.setTextViewText(R.id.w_headline, s.headline)
                v.setTextColor(R.id.w_headline, color)
                val detail = if (s.conditions.isEmpty()) s.detail else s.detail + "\n" + s.conditions
                v.setTextViewText(R.id.w_detail, detail)
                val hora = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.updatedAt))
                val viejo = if (System.currentTimeMillis() - s.updatedAt > 90L * 60L * 1000L) " (datos antiguos)" else ""
                v.setTextViewText(R.id.w_updated, "Actualizado $hora$viejo")
            }
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, pi)
            return v
        }
    }
}
