package com.radartormenta.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class RainTileSource(name: String, private val base: String) :
    OnlineTileSourceBase(name, 0, 7, 256, ".png", arrayOf("https://tilecache.rainviewer.com/")) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$base/256/$z/$x/$y/2/1_1.png"
    }
}

class SatTileSource(name: String, private val base: String, level: Int, private val ext: String) :
    OnlineTileSourceBase(name, 0, level, 256, ".$ext", arrayOf("https://gibs.earthdata.nasa.gov/")) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$base/GoogleMapsCompatible_Level$maximumZoomLevel/$z/$y/$x.$ext"
    }
}

class Frame(val time: Long, val overlay: TilesOverlay)

class MainActivity : Activity() {

    private lateinit var map: MapView
    private lateinit var tvHeadline: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvFrame: TextView
    private lateinit var btnPlay: Button

    private val ui = Handler(Looper.getMainLooper())
    private val radar = ArrayList<Frame>()
    private val sat = ArrayList<Frame>()
    private val shown = ArrayList<TilesOverlay>()
    private var mode = 2
    private var current = 0
    private var playing = true
    private var myLoc: MyLocationNewOverlay? = null
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val ticker = object : Runnable {
        override fun run() {
            var delay = 700L
            if (playing && count() > 1) {
                val next = (current + 1) % count()
                showFrame(next)
                if (next == count() - 1) delay = 1800L
            }
            ui.postDelayed(this, delay)
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 5L * 60L * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cfg = Configuration.getInstance()
        cfg.load(this, getSharedPreferences("osm", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osm")
        cfg.osmdroidTileCache = File(cacheDir, "osm/tiles")

        setContentView(R.layout.activity_main)

        map = findViewById(R.id.map)
        tvHeadline = findViewById(R.id.tvHeadline)
        tvInfo = findViewById(R.id.tvInfo)
        tvFrame = findViewById(R.id.tvFrame)
        btnPlay = findViewById(R.id.btnPlay)
        val btnLocate = findViewById<Button>(R.id.btnLocate)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.setTilesScaledToDpi(true)
        map.setMinZoomLevel(4.0)
        map.setMaxZoomLevel(6.0)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        val (lat, lon) = Store.savedLocation(this)
        map.controller.setZoom(6.0)
        map.controller.setCenter(GeoPoint(lat, lon))

        btnLocate.setOnClickListener {
            val p = myLoc?.myLocation
            if (p != null) {
                map.controller.animateTo(p)
            } else {
                val (la, lo) = Store.savedLocation(this)
                map.controller.animateTo(GeoPoint(la, lo))
            }
        }

        btnPlay.setOnClickListener {
            playing = !playing
            btnPlay.text = if (playing) "❚❚" else "▶"
        }

        findViewById<Button>(R.id.btnMode).setOnClickListener {
            mode = (mode + 1) % 3
            showFrame(current)
        }

        askPermissions()
    }

    // ---------------- Permisos

    private fun askPermissions() {
        val needed = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 1)
        } else {
            afterPermissions()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 1) return
        afterPermissions()
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(
                this,
                "Para recibir avisos con la app cerrada elige \"Permitir todo el tiempo\" en ubicación",
                Toast.LENGTH_LONG
            ).show()
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }
    }

    private fun afterPermissions() {
        setupLocation()
        Scheduler.ensure(applicationContext)
        loadRadar()
        loadSat()
        ui.removeCallbacks(refresher)
        ui.post(refresher)
    }

    private fun setupLocation() {
        if (myLoc != null) return
        val ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        val o = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        o.enableMyLocation()
        o.runOnFirstFix(Runnable {
            runOnUiThread {
                val p = o.myLocation
                if (p != null) {
                    map.controller.animateTo(p)
                }
                refreshStatus()
            }
        })
        map.overlays.add(o)
        myLoc = o
    }

    // ---------------- Radar

    private fun loadRadar() {
        Thread {
            try {
                val json = JSONObject(StormChecker.httpGet("https://api.rainviewer.com/public/weather-maps.json"))
                val host = json.getString("host")
                val past = json.getJSONObject("radar").getJSONArray("past")
                val list = ArrayList<Pair<Long, String>>()
                for (i in 0 until past.length()) {
                    val o = past.getJSONObject(i)
                    list.add(Pair(o.getLong("time"), host + o.getString("path")))
                }
                runOnUiThread { buildRadar(list.takeLast(8)) }
            } catch (e: Exception) {
                runOnUiThread { tvFrame.text = "Sin conexión con el radar" }
            }
        }.start()
    }

    private fun count(): Int = maxOf(radar.size, sat.size)

    private fun makeOverlay(src: OnlineTileSourceBase, a: Float): TilesOverlay {
        val provider = MapTileProviderBasic(applicationContext, src)
        val ov = TilesOverlay(provider, this)
        ov.loadingBackgroundColor = Color.TRANSPARENT
        ov.loadingLineColor = Color.TRANSPARENT
        ov.setColorFilter(
            ColorMatrixColorFilter(
                ColorMatrix(
                    floatArrayOf(
                        1f, 0f, 0f, 0f, 0f,
                        0f, 1f, 0f, 0f, 0f,
                        0f, 0f, 1f, 0f, 0f,
                        0f, 0f, 0f, a, 0f
                    )
                )
            )
        )
        ov.isEnabled = false
        return ov
    }

    private fun buildRadar(list: List<Pair<Long, String>>) {
        radar.clear()
        for ((t, base) in list) {
            radar.add(Frame(t, makeOverlay(RainTileSource("rv_$t", base), 0.9f)))
        }
        rebuildOverlays()
    }

    private fun rebuildOverlays() {
        for (o in shown) map.overlays.remove(o)
        shown.clear()
        var idx = 0
        for (f in sat) {
            map.overlays.add(idx++, f.overlay)
            shown.add(f.overlay)
        }
        for (f in radar) {
            map.overlays.add(idx++, f.overlay)
            shown.add(f.overlay)
        }
        if (count() > 0) {
            current = count() - 1
            showFrame(current)
        }
    }

    private fun showFrame(i: Int) {
        if (count() == 0 || i < 0 || i >= count()) return
        for (o in shown) o.isEnabled = false
        current = i
        val r = radar.getOrNull(i)
        val s = sat.getOrNull(i)
        if (mode != 1 && r != null) r.overlay.isEnabled = true
        if (mode != 0 && s != null) s.overlay.isEnabled = true
        val t = (if (mode != 1) r?.time else s?.time) ?: r?.time ?: s?.time ?: 0L
        val label = when (mode) {
            0 -> "Radar"
            1 -> "Nubes"
            else -> "Nubes + radar"
        }
        tvFrame.text = fmt.format(Date(t * 1000L)) + " · " + label
        map.invalidate()
    }

    // Satelite GOES-Este (NASA GIBS): se prueban capas/niveles hasta encontrar una que responda
    private fun loadSat() {
        Thread {
            try {
                val gibs = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best"
                val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:00'Z'", Locale.US)
                iso.timeZone = TimeZone.getTimeZone("UTC")
                val step = 10L * 60L * 1000L
                val lastMs = (System.currentTimeMillis() - 35L * 60L * 1000L) / step * step
                val layers = arrayOf("GOES-East_ABI_Band13_Clean_Infrared", "GOES-East_ABI_GeoColor")
                val levels = intArrayOf(6, 7, 5)
                val exts = arrayOf("png", "jpg")
                var foundLayer: String? = null
                var foundLevel = 0
                var foundExt = ""
                var baseMs = 0L
                outer@ for (layer in layers) {
                    for (lv in levels) {
                        for (ext in exts) {
                            for (k in 0..2) {
                                val ms = lastMs - k * step
                                val u = "$gibs/$layer/default/${iso.format(Date(ms))}/GoogleMapsCompatible_Level$lv/3/4/2.$ext"
                                val b = StormChecker.httpGetBytes(u)
                                if (b != null && b.isNotEmpty()) {
                                    foundLayer = layer
                                    foundLevel = lv
                                    foundExt = ext
                                    baseMs = ms
                                    break@outer
                                }
                            }
                        }
                    }
                }
                val layer = foundLayer
                if (layer == null) {
                    runOnUiThread { Toast.makeText(this, "Nubes por satélite no disponibles ahora", Toast.LENGTH_LONG).show() }
                    return@Thread
                }
                val lv = foundLevel
                val ext = foundExt
                val bms = baseMs
                runOnUiThread {
                    sat.clear()
                    for (j in 0 until 8) {
                        val ms = bms - (7 - j) * step
                        val stamp = iso.format(Date(ms))
                        val src = SatTileSource("sat_$ms", "$gibs/$layer/default/$stamp", lv, ext)
                        sat.add(Frame(ms / 1000L, makeOverlay(src, 0.75f)))
                    }
                    rebuildOverlays()
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------------- Estado

    private fun refreshStatus() {
        val loc = myLoc?.myLocation
        if (loc != null) Store.saveLocation(this, loc.latitude, loc.longitude)
        val (lat, lon) = Store.currentLocation(this)
        val app = applicationContext
        Thread {
            try {
                val s = StormChecker.check(app, lat, lon)
                Store.saveStatus(app, s)
                runOnUiThread { showStatus(s) }
                StormWidget.refreshAll(app)
            } catch (e: Exception) {
                runOnUiThread { tvHeadline.text = "Sin datos" }
            }
        }.start()
    }

    private fun showStatus(s: Status) {
        tvHeadline.text = s.headline
        tvHeadline.setTextColor(
            when (s.level) {
                2 -> Color.parseColor("#FF4D4D")
                1 -> Color.parseColor("#FFB020")
                else -> Color.parseColor("#3DDC84")
            }
        )
        tvInfo.text = if (s.conditions.isEmpty()) s.detail else s.detail + "\n" + s.conditions
    }

    // ---------------- Ciclo de vida

    override fun onResume() {
        super.onResume()
        map.onResume()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        Store.loadStatus(this)?.let { showStatus(it) }
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        ui.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(refresher)
        ui.removeCallbacks(ticker)
        map.onDetach()
    }
}
