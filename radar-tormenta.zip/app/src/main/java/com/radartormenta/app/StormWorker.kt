package com.radartormenta.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class StormWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            Monitor.run(applicationContext)
        } catch (e: Exception) {
        }
        Result.success()
    }
}

object Monitor {
    fun run(ctx: Context) {
        val (lat, lon) = Store.currentLocation(ctx)
        val s = StormChecker.check(ctx, lat, lon)
        Store.saveStatus(ctx, s)
        StormWidget.refreshAll(ctx)

        val now = System.currentTimeMillis()
        val lastLevel = Store.lastAlertLevel(ctx)
        val lastTime = Store.lastAlertTime(ctx)
        if (s.level >= 2) {
            if (Store.alertsOn(ctx) && (lastLevel < 2 || now - lastTime > 60L * 60L * 1000L)) {
                val body = if (s.conditions.isEmpty()) s.detail else s.detail + "\n" + s.conditions
                Notifier.show(ctx, s.headline, body)
                Store.setLastAlert(ctx, 2, now)
            }
        } else {
            Store.setLastAlert(ctx, s.level, lastTime)
        }
    }
}

object Scheduler {
    fun ensure(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<StormWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "storm_monitor", ExistingPeriodicWorkPolicy.KEEP, req
        )
    }

    fun now(ctx: Context) {
        WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<StormWorker>().build())
    }
}
